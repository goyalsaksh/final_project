<?php
    require_once "db.php";
    require_once "validate_session.php";

    if(isset($_POST['submit'])){
        $email1 = $_POST['email1'];
        $sql = "SELECT t1.*, t2.*,t3.*,t4.*,t5.*,t6.*,t7.*,t8.* FROM emp t1
        JOIN family_details t2 
        ON t1.username = t2.username 
        
        JOIN emp2 t3 
        ON t1.username = t3.username
        
        JOIN qualification t4 
        ON t1.username = t4.username
        
        JOIN emp3 t5 
        ON t1.username = t5.username
        
        JOIN job t6 
        ON t1.username = t6.username
        
        JOIN emp4 t7 
        ON t1.username = t7.username
        
        JOIN lang t8 
        ON t1.username = t8.username
        
        
        WHERE t1.username = $email1;";
        
}

?>