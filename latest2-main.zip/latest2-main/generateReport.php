<?php
    require_once "db.php";
    require_once 'fpdf/fpdf.php';

    if(isset($_GET['user'])) {
        $username = $_GET['user'];

        $qry = "
            SELECT t1.*, t2.name, t2.date, t2.pos, t2.func, t2.adv, t2.preadd, t2.peradd
            FROM user_details t1
            JOIN EMP t2
            ON t1.username = t2.username
            WHERE t1.username = '$username'
        ";

        $result = $con->query($qry);

        if($result) {
            $row = $result->fetch_assoc();
            extract($row);
            $pdf = new FPDF();
            $pdf->AddPage();
            $pdf->SetFont('Arial', 'B', 16);
            $pdf->Cell(0, 10, 'Candidate Report', 0, 1);
            $pdf->SetFont('Arial');
            $pdf->Cell(0, 10, "Applicant's name: $name", 0, 1);
            $pdf->Cell(0, 10, "Date of Birth: $date", 0, 1);
            $pdf->Cell(0, 10, "Position Applied for: $pos", 0, 1);
            $pdf->Cell(0, 10, "Function: $func", 0, 1);
            $pdf->Cell(0, 10, "Where did you hear about us: $adv", 0, 1);
            $pdf->Cell(0, 10, "Present Address: $preadd", 0, 1);
            $pdf->Output('output.pdf', 'I');
        }
    }

?>